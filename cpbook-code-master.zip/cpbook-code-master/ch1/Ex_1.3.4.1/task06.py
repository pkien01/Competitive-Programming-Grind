from bisect import bisect_left
print(v == bisect_left(L, v))
