from math import pi
print(round(pi, int(input())))
